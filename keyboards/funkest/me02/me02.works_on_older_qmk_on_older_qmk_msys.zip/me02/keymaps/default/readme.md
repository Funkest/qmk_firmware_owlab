# The default keymap for casasagi

from Ergo42 default keymap
